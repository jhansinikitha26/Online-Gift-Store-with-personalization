// Function to handle the quiz submission and generate personalized gift suggestions
function submitQuiz() {
    // Get the selected values from the quiz form
    const vibe = document.getElementById('vibe').value;
    const knownTime = document.getElementById('known-time').value;
    const resultDisplay = document.getElementById('quiz-result');

    // Define the gift recommendation based on user answers
    let recommendation = '';

    // Logic for determining the gift suggestion based on vibe and how long they've known the recipient
    if (vibe === 'chill') {
        recommendation = 'A cozy blanket, comfy slippers, or a music-themed gift would be perfect!';
    } else if (vibe === 'smart') {
        recommendation = 'Consider a smart gadget, a personalized notebook, or a thought-provoking book!';
    } else if (vibe === 'party') {
        recommendation = 'A party game, colorful decor, or fun accessories would make a great gift!';
    }

    // Add more gift suggestions based on the "How long have you known them?" selection
    if (knownTime === '1') {
        recommendation += ' A thoughtful, personal gift could be a nice option, something meaningful but not too extravagant.';
    } else if (knownTime === '2') {
        recommendation += ' Consider a personalized gift that captures your time together—something with a bit more meaning!';
    } else if (knownTime === '3') {
        recommendation += ' A luxury gift or something really special to celebrate your deep bond would be ideal!';
    }

    // Display the personalized recommendation on the page
    resultDisplay.innerHTML = `Recommended Gift: <strong>${recommendation}</strong>`;
}

// Function to toggle the visibility of the navigation menu (for mobile view)
function toggleMenu() {
    const navLinks = document.getElementById('nav-links');
    navLinks.classList.toggle('active');
}

