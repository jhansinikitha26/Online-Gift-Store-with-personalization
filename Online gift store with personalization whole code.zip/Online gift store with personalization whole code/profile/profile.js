document.addEventListener("DOMContentLoaded", function () {
  const usernameSpan = document.getElementById("username");
  const emailSpan = document.getElementById("email");
  const phoneSpan = document.getElementById("phone");
  const addressSpan = document.getElementById("address");
  const cartItemsList = document.getElementById("cartItems");
  const orderedItemsList = document.getElementById("orderedItems");
  const uploadPic = document.getElementById("uploadPic");
  const profilePic = document.getElementById("profilePic");
  const signoutBtn = document.getElementById("signout-btn");
  const addressModal = document.getElementById("address-modal");
  const newAddressInput = document.getElementById("new-address");
  const saveAddressBtn = document.getElementById("save-address-btn");
  const closeModalBtn = document.getElementById("close-modal-btn");

  // Load user data
  const currentUser = JSON.parse(localStorage.getItem("giftoraUser"));
  const allUsers = JSON.parse(localStorage.getItem("users")) || [];

  if (!currentUser) {
    alert("Please login first.");
    window.location.href = "login.html";
    return;
  }

  // Display user details
  usernameSpan.textContent = currentUser.username;
  emailSpan.textContent = currentUser.email;
  phoneSpan.textContent = currentUser.phone;
  addressSpan.textContent = currentUser.address || "Not Provided";

  // Load profile pic if saved
  const savedPic = localStorage.getItem("profilePic");
  if (savedPic) {
    profilePic.src = savedPic;
  }

  uploadPic.addEventListener("change", function () {
    const file = this.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (e) {
        profilePic.src = e.target.result;
        localStorage.setItem("profilePic", e.target.result);
      };
      reader.readAsDataURL(file);
    }
  });

  // Load cart items
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  cartItemsList.innerHTML = cartItems.length ? cartItems.map(item => `<li>${item.name} - ₹${item.price}</li>`).join('') : "<li>No items in cart.</li>";

  // Load ordered items
  const orderedItems = JSON.parse(localStorage.getItem("orderedItems")) || [];
  orderedItemsList.innerHTML = orderedItems.length ? orderedItems.map(item => `<li>${item.name} - ₹${item.price}</li>`).join('') : "<li>No orders found.</li>";

  // Edit address
  document.getElementById("edit-address-btn").addEventListener("click", () => {
    addressModal.style.display = "block";
    newAddressInput.value = currentUser.address || "";
  });

  closeModalBtn.addEventListener("click", () => {
    addressModal.style.display = "none";
  });

  saveAddressBtn.addEventListener("click", () => {
    const updatedAddress = newAddressInput.value.trim();
    if (updatedAddress) {
      addressSpan.textContent = updatedAddress;
      currentUser.address = updatedAddress;
      localStorage.setItem("giftoraUser", JSON.stringify(currentUser));

      const updatedUsers = allUsers.map(user =>
        user.email === currentUser.email ? { ...user, address: updatedAddress } : user
      );
      localStorage.setItem("users", JSON.stringify(updatedUsers));

      addressModal.style.display = "none";
    }
  });

  // Sign out
  signoutBtn.addEventListener("click", () => {
    localStorage.removeItem("giftoraUser");
    alert("Signed out successfully!");
    window.location.href = "login.html";
  });
});










