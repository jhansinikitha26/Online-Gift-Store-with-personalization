// Reference to order display area and empty state message
const orderHistorySection = document.getElementById("orderHistory");
const noOrdersMessage = document.getElementById("noOrdersMessage");

// Retrieve saved orders from localStorage
const savedOrders = JSON.parse(localStorage.getItem("giftoraOrders")) || [];

// Function to render all orders
function displayOrders() {
    if (savedOrders.length === 0) {
        noOrdersMessage.style.display = "block";
        return;
    }

    savedOrders.forEach(order => {
        const orderDiv = document.createElement("div");
        orderDiv.classList.add("order");

        orderDiv.innerHTML = `
            <img src="${order.imageUrl}" alt="${order.name}" class="order-image" />
            <div class="order-info">
                <h3>${order.name}</h3>
                <p><strong>Price:</strong> ₹${order.price}</p>
                <p><strong>Occasion:</strong> ${order.occasion}</p>
                <p><strong>Ordered for:</strong> ${order.recipient}</p>
                <p><strong>Status:</strong> Shipped</p>
                <p><strong>Order Date:</strong> ${order.date}</p>
            </div>
        `;

        orderHistorySection.appendChild(orderDiv);
    });
}

// Run on page load
displayOrders();


