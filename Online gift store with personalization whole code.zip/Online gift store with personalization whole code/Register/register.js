// Toggle password visibility
function togglePassword(id) {
  const input = document.getElementById(id);
  input.type = input.type === 'password' ? 'text' : 'password';
}

// Register form submit handler
document.getElementById("registerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const password = document.getElementById("password").value.trim();
  const confirmPassword = document.getElementById("confirmPassword").value.trim();
  const message = document.getElementById("message");

  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$/;

  if (!passwordRegex.test(password)) {
    message.textContent = "Password must include upper, lower, digit & special char.";
    return;
  }

  if (password !== confirmPassword) {
    message.textContent = "DO NOT MATCH PASSWORD";
    return;
  }

  // Check if user already exists
  const users = JSON.parse(localStorage.getItem("users")) || [];
  const exists = users.some(user => user.email === email || user.username === username);
  if (exists) {
    message.textContent = "User already exists.";
    return;
  }

  // Store new user
  users.push({ username, email, phone, password });
  localStorage.setItem("users", JSON.stringify(users));

  // Also set current profile for profile page
  localStorage.setItem("giftoraUser", JSON.stringify({ username, email, phone, address: "Not Provided" }));

  message.textContent = "REGISTRATION SUCCESSFUL!";
  setTimeout(() => window.location.href = "login.html", 2000);
});












