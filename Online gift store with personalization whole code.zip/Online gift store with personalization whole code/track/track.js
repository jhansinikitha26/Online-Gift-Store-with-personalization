function trackOrder() {
  const input = document.getElementById('search-input').value.trim().toLowerCase();
  const statusDiv = document.getElementById('order-status');
  statusDiv.innerHTML = '';

  if (!input) {
    statusDiv.innerHTML = `<p style="color: red;">Please enter an Order ID or Recipient Name.</p>`;
    return;
  }

  const orders = JSON.parse(localStorage.getItem('giftoraOrders')) || [];
  const matchedOrders = orders.filter(order =>
    order.recipient?.toLowerCase().includes(input) ||
    order.orderId?.toLowerCase() === input
  );

  if (matchedOrders.length === 0) {
    statusDiv.innerHTML = `<p style="color: gray;">No matching orders found for: <strong>${input}</strong>.</p>`;
    return;
  }

  matchedOrders.forEach(order => {
    const orderDiv = document.createElement('div');
    orderDiv.className = 'order';

    const randomStatus = getRandomStatus();

    orderDiv.innerHTML = `
      <img src="${order.imageUrl}" alt="${order.name}" />
      <div class="order-details">
        <h3>${order.name}</h3>
        <p><strong>Recipient:</strong> ${order.recipient}</p>
        <p><strong>Order ID:</strong> ${order.orderId || '(N/A)'}</p>
        <p><strong>Occasion:</strong> ${order.occasion}</p>
        <p><strong>Date Ordered:</strong> ${order.date}</p>
        <p><strong>Status:</strong> ${randomStatus}</p>
      </div>
    `;
    statusDiv.appendChild(orderDiv);
  });
}

function getRandomStatus() {
  const statuses = ['Processing', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
  return statuses[Math.floor(Math.random() * statuses.length)];
}
