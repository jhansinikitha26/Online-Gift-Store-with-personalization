function toggleMenu() {
    const navLinks = document.getElementById("nav-links");
    navLinks.style.display = (navLinks.style.display === "block") ? "none" : "block";
}
// Toggle menu visibility on button click
function toggleMenu() {
    const navLinks = document.getElementById("nav-links");
    navLinks.classList.toggle("active");
}

