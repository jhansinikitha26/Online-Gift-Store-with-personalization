// Function to handle form submission
document.getElementById('queryForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const queryInput = document.getElementById('query').value;
    if(queryInput) {
        // Create a new query div to display
        const queryDiv = document.createElement('div');
        queryDiv.classList.add('query');
        
        queryDiv.innerHTML = `
            <h3>${queryInput}</h3>
            <p><strong>Response:</strong> We will get back to you shortly!</p>
        `;
        
        // Append the new query to the query responses section
        document.querySelector('.query-responses').appendChild(queryDiv);
        
        // Clear the input field
        document.getElementById('query').value = '';
    }
});



