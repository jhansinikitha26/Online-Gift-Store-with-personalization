document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const usernameEmail = document.getElementById("usernameEmail").value.trim();
    const password = document.getElementById("password").value.trim();
    const message = document.getElementById("loginMessage");
  
    const users = JSON.parse(localStorage.getItem("users")) || [];
  
    const validUser = users.find(user =>
      (user.username === usernameEmail || user.email === usernameEmail) &&
      user.password === password
    );
  
    if (validUser) {
      message.textContent = "Login successful! Redirecting...";
      message.style.color = "green";
  
      // Redirect to home page after 2 seconds
      setTimeout(() => {
        window.location.href = "http://127.0.0.1:5500/home/home.html"; // or "./templates/home.html" if stored inside templates folder
      }, 2000);
    } else {
      message.textContent = "Incorrect username or password.";
      message.style.color = "red";
    }
  });













