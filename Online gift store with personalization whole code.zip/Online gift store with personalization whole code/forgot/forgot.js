document.getElementById("forgotForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const message = document.getElementById("forgotMessage");
  
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const userIndex = users.findIndex(user => user.username === username);
  
    if (userIndex !== -1) {
      users[userIndex].password = newPassword;
      localStorage.setItem("users", JSON.stringify(users));
      message.textContent = "Password reset successful!";
      setTimeout(() => window.location.href = "login.html", 2000);
    } else {
      message.textContent = "Username not found.";
    }
  });








