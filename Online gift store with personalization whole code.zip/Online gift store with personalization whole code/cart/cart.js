// Load cart items from localStorage and render them
function loadCartItems() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartContainer = document.getElementById('cart-items');
    cartContainer.innerHTML = '';

    cartItems.forEach((item, index) => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('cart-item');
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="item-details">
                <h3>${item.name}</h3>
                <p>Price: Rs ${item.price.toFixed(2)}</p>
                <p>Quantity: <span class="quantity">${item.quantity}</span></p>
                <button class="remove-item" data-index="${index}">Remove</button>
                <button class="view-details">View Details</button>
            </div>
        `;
        cartContainer.appendChild(itemDiv);
    });

    attachRemoveHandlers();
    updateCartSummary();
}

function attachRemoveHandlers() {
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', event => {
            const index = event.target.getAttribute('data-index');
            const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
            cartItems.splice(index, 1);
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            loadCartItems();
        });
    });
}

document.addEventListener('click', (event) => {
    if (event.target.classList.contains('view-details')) {
        alert('More details feature coming soon!');
    }
});

function updateCartSummary() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let total = 0;
    cartItems.forEach(item => {
        total += item.price * item.quantity;
    });
    document.getElementById('total-price').textContent = `Rs ${total.toFixed(2)}`;
}

document.querySelector('.checkout').addEventListener('click', () => {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    if (cartItems.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Save orders globally
    const allOrders = JSON.parse(localStorage.getItem('giftoraOrders')) || [];
    const newOrders = cartItems.map(item => ({
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        imageUrl: item.image,
        date: new Date().toLocaleDateString(),
        recipient: "Not Provided",
        occasion: "Not Selected"
    }));
    allOrders.push(...newOrders);
    localStorage.setItem('giftoraOrders', JSON.stringify(allOrders));

    // Save orders to current user
    const currentUser = JSON.parse(localStorage.getItem('giftoraUser'));
    if (currentUser) {
        currentUser.orderedItems = currentUser.orderedItems || [];
        currentUser.orderedItems.push(...newOrders);
        localStorage.setItem('giftoraUser', JSON.stringify(currentUser));
    }

    // ✅ Generate and show Order ID
    const orderId = 'GIFT' + Math.floor(100000 + Math.random() * 900000);
    alert(`Order Confirmed! Your Order ID is ${orderId}`);

    // Empty cart
    localStorage.setItem('cartItems', JSON.stringify([]));

    // Trigger Buy Now modal in shopping page
    localStorage.setItem('openBuyNow', 'true');
    window.location.href = 'shopping.html';
});

window.addEventListener('load', loadCartItems);








