document.getElementById("set-date").addEventListener("click", setDate);

function setDate() {
  const selectedDate = document.getElementById("occasion-date").value;
  const countdownDisplay = document.getElementById("countdown");
  const giftMessage = document.getElementById("gift-message");
  const giftList = document.getElementById("gift-list");

  if (selectedDate) {
    const targetDate = new Date(selectedDate);
    const currentDate = new Date();
    const timeRemaining = targetDate - currentDate;

    if (timeRemaining > 0) {
      const daysRemaining = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
      countdownDisplay.innerHTML = `Countdown: ${daysRemaining} day(s) remaining until the occasion!`;

      giftList.innerHTML = "";

      if (daysRemaining <= 1) {
        giftMessage.textContent = "You're planning a last-minute gift. Try these:";
        giftList.innerHTML += "<li>Instant e-Gift Cards 💳</li>";
        giftList.innerHTML += "<li>Same-day flower delivery 🌸</li>";
        giftList.innerHTML += "<li>Digital greeting with name 💌</li>";
      } else if (daysRemaining <= 5) {
        giftMessage.textContent = "You still have time! Try fast-shipping gifts:";
        giftList.innerHTML += "<li>Customized mugs 🧉</li>";
        giftList.innerHTML += "<li>Pre-packed gift boxes 🎁</li>";
        giftList.innerHTML += "<li>Photo frames 📸</li>";
      } else {
        giftMessage.textContent = "Plenty of time! Go for creative gifts:";
        giftList.innerHTML += "<li>Personalized jewelry 💍</li>";
        giftList.innerHTML += "<li>Custom photo books 📔</li>";
        giftList.innerHTML += "<li>Scheduled surprise deliveries 🎉</li>";
      }
    } else {
      countdownDisplay.innerHTML = "This occasion date has already passed!";
      giftMessage.textContent = "Oops! The occasion is over. Try another date.";
      giftList.innerHTML = "";
    }
  }
}
