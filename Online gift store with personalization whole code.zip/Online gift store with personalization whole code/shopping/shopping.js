// Sample Product Data
const products = [
    { id: 1, name: "Gift 1", price: 525, category: "photo-frame", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61hr6NZerXL.jpg" },
    { id: 1, name: "Gift 2", price: 125, category: "photo-frame", occasion: "birthday", imageUrl: "https://5.imimg.com/data5/SELLER/Default/2023/12/370814576/AR/UT/KH/121831005/3-star-corporate-trophy.jpeg" },
    { id: 1, name: "Gift 3", price: 195, category: "photo-frame", occasion: "birthday", imageUrl: "https://lovingcrafts.in/cdn/shop/files/lovingcrafts-new-products-14.jpg?v=1742023584&width=1445" },
    { id: 1, name: "Gift 4", price: 720, category: "photo-frame", occasion: "birthday", imageUrl: "https://modernarts.in/wp-content/uploads/2024/06/black-photo-Frame-45-copy-7.jpg" },
    { id: 1, name: "Gift 5", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://modernarts.in/wp-content/uploads/2024/06/3rd-Etsy-products-1.jpg" },
    { id: 1, name: "Gift 6", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIVUKjbrK65qVzby6wha27SjPk_usZc0hscg&s" },
    { id: 1, name: "Gift 7", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM6TKLYODmT8y7L6zLUav950r-myY-8MSJ6A&s" },
    { id: 1, name: "Gift 8", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://cdn.dotpe.in/longtail/store-items/7464876/oNmS1Ikk.jpeg" },
    { id: 1, name: "Gift 9", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIDg2j3Mb5NTTX5yyvslMzAFzOYp7qrg0HuQ&s" },
    { id: 1, name: "Gift 10", price: 912, category: "photo-frame", occasion: "birthday", imageUrl: "https://i.etsystatic.com/5185360/r/il/68d2c1/6779023136/il_fullxfull.6779023136_sybl.jpg" },

    { id: 1, name: "Gift 1", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://zocivoci.com/wp-content/uploads/2023/11/MO-B-scaled.jpg" },
    { id: 1, name: "Gift 2", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQs_ZuurZhIxIHNORTqAxn2xWB1rAFO2Xpvsg&s" },
    { id: 1, name: "Gift 3", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT73z9UBdQJxTtYO7Su93yDF_ImOaHY7__jLg&s" },
    { id: 1, name: "Gift 4", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAdTLV1nZXF8yyr8uSgfnPtJC_92u9KXMaTw&s" },
    { id: 1, name: "Gift 5", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3SuSlGP-qVnrlw9w8k80uC7Tp5QgBgQQfGA&s" },
    { id: 1, name: "Gift 6", price: 912, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm77qEPA8ZL0cD6NMICYRaC9Y3D2Ak7fdzSQ&s" },
    { id: 1, name: "Gift 7", price: 912.99, category: "photo-frame", occasion: "anniversary", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/wall-decoration/t/o/c/happy-anniversary-wooden-wall-hanging-photo-frame-for-home-decor-original-imah7n2agrbggmeh.jpeg?q=20&crop=false" },
    { id: 1, name: "Gift 8", price: 912.99, category: "photo-frame", occasion: "anniversary", imageUrl: "https://cdn0.weddingwire.in/article/4134/original/1280/jpg/124314-giftzonechennai.jpeg" },
    { id: 1, name: "Gift 9", price: 912.99, category: "photo-frame", occasion: "anniversary", imageUrl: "https://cdn.igp.com/f_auto,q_auto,t_pnopt19prodlp/products/p-personalized-led-frame-for-anniversaries-177801-m.jpg" },
    { id: 1, name: "Gift 10", price: 912.99, category: "photo-frame", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSZswuRVDTM7fnoxO3s03CQ_LmmMEnlUhu7Q&s" },

    { id: 1, name: "Gift 1", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzDqIOvttitzndvdsuOkTGg7UrvmTyYUHH8Q&s" },
    { id: 1, name: "Gift 2", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://cdn.igp.com/f_auto,q_auto,t_pnopt19prodlp/products/p-personalized-be-my-valentine-wooden-photo-frame-125021-m.jpg" },
    { id: 1, name: "Gift 3", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTA3hn6LXbGRTaKCXFwaNbG9_Lhv_WT-Xl_4g&s" },
    { id: 1, name: "Gift 4", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2PqKk9CbL1qmVxt7VAAZ5fWpaSwYj3209dA&s" },
    { id: 1, name: "Gift 5", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTA_bnzig1h7lccIHtTh1J8B7IDm-uHhJhsrw&s" },
    { id: 1, name: "Gift 6", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIn5YC1m1FkQ5dhXDjFYpIqGsNqi9kP_tdKA&s" },
    { id: 1, name: "Gift 7", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSg3GL2RT7fF8KoR4LyzzLh5Flq8EeWqKzNEQ&s" },
    { id: 1, name: "Gift 8", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://www.jiomart.com/images/product/original/rvk4jn5e7d/gifts-lab-personalised-couple-photo-frame-the-love-story-10-14-inch-couple-frame-anniversary-gift-valentine-s-day-gift-customized-gift-product-images-orvk4jn5e7d-p607638103-0-202401312001.jpg?im=Resize=(1000,1000)" },
    { id: 1, name: "Gift 9", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBxzJmbVRlepotUwVus8HejI77b-X4JEoS2g&s" },
    { id: 1, name: "Gift 10", price: 912.99, category: "photo-frame", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgqMW-4mJ5RA6r7OFtI9r5ciKXVtAuoPdZ_A&s" },

    { id: 1, name: "Gift 1", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://i.ytimg.com/vi/KqWaqLckeXA/maxresdefault.jpg" },
    { id: 1, name: "Gift 2", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61+CtuzEEvL._SY300_SX300_.jpg" },
    { id: 1, name: "Gift 3", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://www.fnp.com/images/pr/l/v20240502173509/best-mom-ever-photo-frame-for-mothers-day_2.jpg" },
    { id: 1, name: "Gift 4", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://nutcaseshop.com/cdn/shop/products/3a.jpg?v=1651197929&width=1445" },
    { id: 1, name: "Gift 5", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYSf4jHBWfHEIcUj0VdSuUEQlPvHVx-GW4dA&s" },
    { id: 1, name: "Gift 6", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBHgD1RtXoU4T-v9fru9xR5xpx2ah4NnoN0g&s" },
    { id: 1, name: "Gift 7", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/17484706/r/il/f38b7c/6591028842/il_570xN.6591028842_p20a.jpg" },
    { id: 1, name: "Gift 8", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMg6MVi512WU2FgY6E1ZHmGm01uSZobWkUeA&s" },
    { id: 1, name: "Gift 9", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCUW-W6xWcHmyZX0StteVmg1fcq8640gRU4Q&s" },
    { id: 1, name: "Gift 10", price: 912.99, category: "photo-frame", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/469929858/lc2g5_512.webp" },

    { id: 1, name: "Gift 1", price: 912.99, category: "photo-frame", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVgVoloGPJUqdL7ia2l8rHBn_ciPDn1nrbjw&s" },
    { id: 1, name: "Gift 2", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTV9A8_ewtIlsfvXOxOLljZcSXeeu4HeaoK4A&sp" },
    { id: 1, name: "Gift 3", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl: "https://www.incrediblegifts.in/wp-content/uploads/2023/05/trophy1.jpg" },
    { id: 1, name: "Gift 4", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"https://m.media-amazon.com/images/I/718ShlKug5L.jpg" },
    { id: 1, name: "Gift 5", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqnfHncSn0cWbhePT0GKaX6vz9qGkF0IdJdg&s" },
    { id: 1, name: "Gift 6", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTdV42b9QwT7RW6D-7BAvkLfHrU7qHFTD9xA&s" },
    { id: 1, name: "Gift 7", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"fathers day", imageUrl: "https://m.media-amazon.com/images/I/61n+L6C9nOL.jpg" },
    { id: 1, name: "Gift 8", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgkNlGFISQEoYqI_GMSq8QY63Ie6ULYUMXSQ&s" },
    { id: 1, name: "Gift 9", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdnQyeVvsuiGJ6iVwm8kG--91jUglgiFvnTw&s" },
    { id: 1, name: "Gift 10", price: 912.99, category: "photo-frame", occasion:"fathers-day",imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/normal-photo-frame/q/f/z/best-dad-5-ph-wooden-wall-hanging-frame-birthday-fathers-day-original-imagpcfx5zqh6ngs.jpeg?q=20&crop=false" },


    
    { id: 2, name: "Gift 1", price: 800, category: "cups", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5vmWH3ENNzkX2GruUV7hS1m1IYQ4ygTIG9w&s" },
    { id: 2, name: "Gift 2", price: 700, category: "cups", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61M+5U6n1HL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 3", price: 795, category: "cups", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/51TDWtv5hpL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 4", price: 800, category: "cups", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVkts5lZHDfXa2UkOcERoyyA7-fGxtUj9-0g&s" },
    { id: 2, name: "Gift 5", price: 600, category: "cups", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61LVSZcoRuL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 6", price: 650, category: "cups", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUH_NehJL0-82AMK_XJc7eoz7GiPEno70gew&s" },
    { id: 2, name: "Gift 7", price: 500, category: "cups", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYUoDDHoIChww1yUSqPPdbOQEfszESE0lhNg&s" },
    { id: 2, name: "Gift 8", price: 700, category: "cups", occasion: "birthday", imageUrl: "https://www.jiomart.com/images/product/original/rvlmohi2pu/trendoprint-customized-personalized-happy-birthday-coffee-mug-350ml-11oz-set-of-1-best-return-gift-for-birthday-kids-friends-product-images-orvlmohi2pu-p601605173-0-202305181705.jpg?im=Resize=(420,420)" },
    { id: 2, name: "Gift 9", price: 750, category: "cups", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTCStz6msTluqGAYYbiQLlvZ7B1uc2qChLCUw&s" },
    { id: 2, name: "Gift 10", price: 650, category: "cups", occasion: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFXTfMT9bgtOo09HYUqueptcTmCoHApmIHFg&s" },
    
    { id: 2, name: "Gift 1", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQVQAtx6uMM5tud1veebjPKgmuLn5R5X38Tw&s" },
    { id: 2, name: "Gift 2", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/51aKswSTYcL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 3", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/61EAEDRI4KL.jpg" },
    { id: 2, name: "Gift 4", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://assets.winni.in/c_limit,dpr_1,fl_progressive,q_80,w_1000/83325_personalised-anniversary-mug.jpeg" },
    { id: 2, name: "Gift 5", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPK7vbBPRBaGhHwEv69oxylyiQSY_4mrcagw&s" },
    { id: 2, name: "Gift 6", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://images.meesho.com/images/products/416658593/0ajvz_512.webp" },
    { id: 2, name: "Gift 7", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://www.jiomart.com/images/product/original/rvetvyjcay/goldencity-ceramic-25-years-together-coffee-mug-gifts-for-anniversary-couple-anniversary-gifts-perfect-to-gift-to-loved-ones-festival-coffee-mug-gifts-product-images-orvetvyjcay-p610005331-2-202409201514.jpg?im=Resize=(420,420)" },
    { id: 2, name: "Gift 8", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbByNcmq2S-VeILt0eO4yrtXq_i9ZWB0Zblg&s" },
    { id: 2, name: "Gift 9", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://images.meesho.com/images/products/458831620/jz4qf_512.webp" },
    { id: 2, name: "Gift 10", price: 19.99, category: "cups", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTttJBENV4jlzo1H67Yke0I-uXYyYbZXUB3Qg&s" },

    { id: 2, name: "Gift 1", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfVxoCvWTJ7Eqv9jBMo_v1JreNAaiRYczF3w&s" },
    { id: 2, name: "Gift 2", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgjKqf_n3brxM_01qg-f6crITpx01vFj_dcw&s" },
    { id: 2, name: "Gift 3", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPKkDeBbpsw1XRrydtk_3U4CLZ0JAoQFRI9w&s" },
    { id: 2, name: "Gift 4", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://knitroot.com/wp-content/uploads/2022/06/Valentines-Day-1.jpg" },
    { id: 2, name: "Gift 5", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8wuMjH9Q3Ql7axReUpj-ZnWjOl9c0taXP6A&s" },
    { id: 2, name: "Gift 6", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/61awoILrjOL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 7", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTG5dPcgeJzqIXIIDQKoKlWRPGLyvYiiMjryg&s" },
    { id: 2, name: "Gift 8", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://5.imimg.com/data5/UP/BV/MY-2678014/valentine-27s-day-gift-mugs-500x500.jpg" },
    { id: 2, name: "Gift 9", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvhYOZx1ZVmBr1Om-F_lPkIZEMpxdAq9WfKw&s" },
    { id: 2, name: "Gift 10", price: 19.99, category: "cups", occasion: "valentines", imageUrl: "https://images.meesho.com/images/products/220096587/gq8ib_512.webp" },



    { id: 2, name: "Gift 1", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61xZ1Zf+xrL.jpg" },
    { id: 2, name: "Gift 2", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/618SGEC-2XL.jpg" },
    { id: 2, name: "Gift 3", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/71gS6LG5yAL.jpg" },
    { id: 2, name: "Gift 4", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6LJKWtimkWm8uA_pbV09s6dDcBiDumOZJDw&s" },
    { id: 2, name: "Gift 5", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/417812892/gjhyo_512.webp" },
    { id: 2, name: "Gift 6", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://www.jiomart.com/images/product/original/rv1i2uibon/yubingo-birthday-gift-for-mom-ceramic-coffee-mug-printed-tea-cup-best-mother-s-day-gift-from-daughter-birthday-gift-for-mom-black-colour-changing-magic-mug-magic-320ml-product-images-orv1i2uibon-p591362068-4-202205161613.jpg?im=Resize=(420,420)" },
    { id: 2, name: "Gift 7", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/252438715/yrp9n_512.webp" },
    { id: 2, name: "Gift 8", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61VQGSzFCnL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 9", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbheo2KQYTbl2ocscDyZbtbj187TOAlg9IgA&s" },
    { id: 2, name: "Gift 10", price: 19.99, category: "cups", occasion: "mothers-day", imageUrl: "https://www.bettergiftflowers.com/wp-content/uploads/2024/04/Happy-Mothers-Day-Mug-1.jpg" },



    { id: 2, name: "Gift 1", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/61Kxat8MlVL.jpg" },
    { id: 2, name: "Gift 2", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhaxVjey5rGZX54vtpcHpC2F8wFZIwwaA0Ig&s" },
    { id: 2, name: "Gift 3", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://www.incrediblegifts.in/wp-content/uploads/2023/05/A-3-600x511.jpg" },
    { id: 2, name: "Gift 4", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://images.meesho.com/images/products/247659277/qymbn_512.webp" },
    { id: 2, name: "Gift 5", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3g2ukvZr1C_1bj2R1k1mDuoZzVUBpZxC7fQ&s" },
    { id: 2, name: "Gift 6", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3mC-ugpN5EhXdnwnIh1tuf_qLBz7P3Yu4Iw&s" },
    { id: 2, name: "Gift 7", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://images.meesho.com/images/products/398383690/m6hcc_512.webp" },
    { id: 2, name: "Gift 8", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/31q+qbC-VAL._AC_UF894,1000_QL80_.jpg" },
    { id: 2, name: "Gift 9", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqUs5K1J-DCgd3cXmYHxFHvpIIEptP8fzaiQ&s" },
    { id: 2, name: "Gift 10", price: 19.99, category: "cups", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTN5ZpH6tPGaTmGxeCGF4oyjlmgq0Y2TOdm6A&s" },


    { id: 3, name: "Gift 1", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmmqr4me29X33ebmCJ1Df3aRjdnRrv_YrDOg&s" },
    { id: 3, name: "Gift 2", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61mXsmG4MhL._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 3", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://images.meesho.com/images/products/155724876/9kwx0_512.webp" },
    { id: 3, name: "Gift 4", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSq6zOuT6YRP3jw7sQXetvEeMRSnSwcmlxMiQ&s" },
    { id: 3, name: "Gift 5", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://rukminim2.flixcart.com/image/720/864/kggviq80-0/watch/e/g/d/love-style-gold-plated-watches-for-girls-women-watch-analog-original-imafwpa5x56aygdm.jpeg?q=60&crop=false" },
    { id: 3, name: "Gift 6", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/jyj0how0/watch/4/u/g/lag-oc-01-lagniappe-original-imafgpy8zfk9yqeb.jpeg?q=90&crop=false" },
    { id: 3, name: "Gift 7", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://www.jiomart.com/images/product/original/rvbon6uyhv/goldenize-fashion-analogue-brown-dial-with-king-bracelet-birthday-gift-premium-watch-for-boys-men-s-boy-s-combo-watches-product-images-rvbon6uyhv-0-202302252304.jpg?im=Resize=(500,630)" },
    { id: 3, name: "Gift 8", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRLDVV6dmbxW9QfdIdoSEM-iI4-y8kEmsBFA&s" },
    { id: 3, name: "Gift 9", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/612-u4+-qYL._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 10", price: 29.99, category: "watches", occasion: "birthday", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/watch/v/c/q/1-blackjuni-omenterprisehub-men-women-original-imageqtkt8zafwhg.jpeg?q=90&crop=false" },


    { id: 3, name: "Gift 1", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR40SBSwvuRsT8UUjnkkzuZjL5qmqcWk2-Qcg&s" },
    { id: 3, name: "Gift 2", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjQVyjeaEx7VPpK52D7r5g6QGHIkQb7BR8bw&s" },
    { id: 3, name: "Gift 3", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoTc6iT9uvQA0dK5O4dbFXtR3aEIH1H3JC9Q&s" },
    { id: 3, name: "Gift 4", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxj62SO27q73DlVmV8YUgcfsxU_gtu79x5sw&s" },
    { id: 3, name: "Gift 5", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/51f3U++z4UL._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 6", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2lWb1j2PNzeaRzEJ3N_XrggmgXb43RgrLWg&s" },
    { id: 3, name: "Gift 7", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTPUOPFE2QbTWfJ1ppzJn8rf70BG_9BqhnCg&s" },
    { id: 3, name: "Gift 8", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQZzdybeTMnNRHocGp5Mi0MNAPE9fOUAmoBQ&s" },
    { id: 3, name: "Gift 9", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3JEkxJIE_3bh-zLb9sejAuA2WzIwJV2XNog&s" },
    { id: 3, name: "Gift 10", price: 29.99, category: "watches", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7WukLgLa-lC1_V3BV9NVowZjAFOk4D7xngw&s" },
    



    { id: 3, name: "Gift 1", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyGbYaqFhG7LQ1j5zVLKNSvBgEPtE8HrJt1A&s" },
    { id: 3, name: "Gift 2", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK5qfXYCxxzPwBFETo22xDG13p_aURXQykYg&s" },
    { id: 3, name: "Gift 3", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsKp6jYTRV8foWzyfszjD4BDbKttmc9_8g1w&s" },
    { id: 3, name: "Gift 4", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnSyq9nS057FQ6DDR_qs4MnKiftIm2lMaZcA&s" },
    { id: 3, name: "Gift 5", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2Uflx_gFVSnpJJt-NIOgp6m8hruJdlLTPDQ&s" },
    { id: 3, name: "Gift 6", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRu5D8YpsQmWYZJkLcwP3WRgew3aMukTZd8CA&s" },
    { id: 3, name: "Gift 7", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPfl7K-zeHK_p7e2J1Y4IFJRTZaQSzQq138w&s" },
    { id: 3, name: "Gift 8", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBKLGKig92JO1LCxAiCqUxQNqu46aDR9iQ0w&s" },
    { id: 3, name: "Gift 9", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4No8Lb-2RCZLu37lxiMrqtlcq-SfIQ2quVA&s" },
    { id: 3, name: "Gift 10", price: 29.99, category: "watches", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBgSIZbSFa69bAfmHDetzZM0v0pbUJ7ZVhIg&s" },
   

    { id: 3, name: "Gift 1", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlKA74YddqasWStvJwebswy5Lum50c763_ng&s" },
    { id: 3, name: "Gift 2", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB5hJS8HcB1MTqA0CdwqhxvhbVhzwT96c_4Q&s" },
    { id: 3, name: "Gift 3", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://www.kapoorwatch.com/blogs/wp-content/uploads/Banner-7-6.webp" },
    { id: 3, name: "Gift 4", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://cdn4.ethoswatches.com/the-watch-guide/wp-content/uploads/2018/05/mobile-mast-1.jpg" },
    { id: 3, name: "Gift 5", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61aFVofc+2L._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 6", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61D1CEePAML._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 7", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://c.ndtvimg.com/2021-05/8g2t4j2g_mothers-day650_625x300_01_May_21.jpg" },
    { id: 3, name: "Gift 8", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwu9j5qdatxcWnTH-wrIjZKQuGUpf_BaqvaA&s" },
    { id: 3, name: "Gift 9", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1uuQWgqi8fOLqn_5-N07iQ-MHss8Rq7GXOg&s" },
    { id: 3, name: "Gift 10", price: 29.99, category: "watches", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcToDKhIm4XNaeNfAL-I_GxxcRi781U_6SZyZA&s" },
    

    { id: 3, name: "Gift 1", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://cdn4.ethoswatches.com/the-watch-guide/wp-content/uploads/2020/06/Fathers-Day-Girard-Perregaux-Bulgari-Parmigiani-Jaeger-LeCoultre-H-Moser-Cie-Carl-F-Bucherer-Rado-Nomos-Corum-Oris-Omega-MeisterSinger-FRC-MM.jpg" },
    { id: 3, name: "Gift 2", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBwoDGPc_5l2T8HfduCPUg3mGnA4UVT7gk3g&s" },
    { id: 3, name: "Gift 3", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://robbreport.com/wp-content/uploads/2021/05/FathersDay.jpg?w=1000" },
    { id: 3, name: "Gift 4", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhx9m18KqAQJ7wsc0W11NwECT5Uq5YBJoOJg&s" },
    { id: 3, name: "Gift 5", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnKxbVQZbe6ZZq9L3r_3QB18yVGSeSuYb6NQ&s" },
    { id: 3, name: "Gift 6", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjKiEi6Qj6Mq9GCWtAAIQbMKX8fQ6Mw6J-0A&s" },
    { id: 3, name: "Gift 7", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKEFGI9v-Fdzpz8loWYtDvA8oUvIErfeENkw&s" },
    { id: 3, name: "Gift 8", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/71FytYMSDzL._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 9", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/61gbfieQHAL._AC_UY1000_.jpg" },
    { id: 3, name: "Gift 10", price: 29.99, category: "watches", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnBNncsibqXILiVFpjjgV8jMPRccki87m07g&s" },

    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61nVR6sGZoL._AC_UF1000,1000_QL80_.jpg" },

    { id: 4, name: "Gift 1", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/stuffed-toy/b/r/9/soft-plush-teddy-bear-with-birthday-balloon-gift-for-birthday-original-imaghysb5hars9ef.jpeg?q=20&crop=false" },
    { id: 4, name: "Gift 2", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/71QJZBJH+3L._AC_UF1000,1000_QL80_.jpg" },
    { id: 4, name: "Gift 3", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpIpYzlY4P4j793-hMelz3vgP_Y6-fom4bTg&s" },
    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIdDld4yBaJfQEKWa0Mq6fpupzNQwdG4t_fg&s" },
    { id: 4, name: "Gift 5", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5O2Z_0HUezWbI0gN79589N5wnGraqTk-dAw&s" },
    { id: 4, name: "Gift 6", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuncW22pzqQIPhzCHSc_HGOVAlEt46THFK5w&s" },
    { id: 4, name: "Gift 7", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMgNBNIGcwaPKLB8gXHGugCks-f7_h7CsawA&s" },
    { id: 4, name: "Gift 8", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/71saFEXAR2L._AC_UF1000,1000_QL80_.jpg" },
    { id: 4, name: "Gift 9", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1n-HweGQNt8jDgiG93wQwZ3IHC6IjrNjQ1Q&s" },
    { id: 4, name: "Gift 10", price: 34.99, category: "teddy-bears", occasion: "birthday", imageUrl: "https://imgcdn.floweraura.com/vanilla-birthday-cake-with-teddy-9794410co-A_0.jpg" },



    { id: 4, name: "Gift 1", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/91+mCBuMgVL.jpg" },
    { id: 4, name: "Gift 2", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://i.etsystatic.com/9758082/r/il/0ad8f6/5151456635/il_570xN.5151456635_ojf0.jpg" },
    { id: 4, name: "Gift 3", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/41UZzoButtL._AC_UF894,1000_QL80_.jpg" },
    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJasGLb1nuXCEGs7U-Ccl400q8ELTrOaIooA&s" },
    { id: 4, name: "Gift 5", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZql4XlN_pQEztZfiwEl5LUkyXH2DlKganbw&s" },
    { id: 4, name: "Gift 6", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwRCg3Trn9ePnfDr89sNRR1GjFTdmbAQnXyQ&s" },
    { id: 4, name: "Gift 7", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnBzJ3_87PLlG8rzTbWzLSZiusS5udYpqcnQ&s" },
    { id: 4, name: "Gift 8", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlkR8lsL6nWbKXopFdpQXPjsAz84pcVMR6UQ&s" },
    { id: 4, name: "Gift 9", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN172_ovQni3udEFpu1s0ZeRD58C40Wg9MNQ&s" },
    { id: 4, name: "Gift 10", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://www.jiomart.com/images/product/original/rvuw4hrndt/notting-hill-soft-toys-teddy-bear-for-kids-super-soft-stuffed-animal-lovable-huggable-perfect-for-birthday-anniversary-valentine-gift-blue-product-images-orvuw4hrndt-p609899920-3-202409301924.jpg?im=Resize=(420,420)" },
    { id: 4, name: "Gift 11", price: 34.99, category: "teddy-bears", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGk10XeF02ncYbxGk30HrBGxsYB7Yz3fcgVg&s" },


    { id: 4, name: "Gift 1", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTY__iCBvQOjGgeGnb6vIkh9MmtGnITS7icXA&s" },
    { id: 4, name: "Gift 2", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/71gxtMM5uBL.jpg" },
    { id: 4, name: "Gift 3", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/51ByeDjKKwL._AC_UF1000,1000_QL80_.jpg" },
    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://images-cdn.ubuy.co.in/634e88abac6d647c6f596b78-way-to-celebrate-valentine-s-day-large.jpg" },
    { id: 4, name: "Gift 5", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDvfgRcaU5g3cKYQ2cMpVIjos_McyMpB6__Q&s" },
    { id: 4, name: "Gift 6", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/817jJr5XIAL.jpg" },
    { id: 4, name: "Gift 7", price: 34.99, category: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOn50Q0m2BgZSS2F09Rny5WQS_BcTG7HYUqw&s" },
    { id: 4, name: "Gift 8", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJAqKnSwMzrbYyV_MEzxfbZJQkXjWwiqJedg&s" },
    { id: 4, name: "Gift 9", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOOhJPcykdfYkhFaW9eCfo9nWeWevQqSGvJg&s" },
    { id: 4, name: "Gift 10", price: 34.99, category: "teddy-bears", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9O27IzEMWkgvralHrVNYwWvXVyGGEl9jDgg&s" },


    { id: 4, name: "Gift 1", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61nVR6sGZoL._AC_UF1000,1000_QL80_.jpg" },
    { id: 4, name: "Gift 2", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/41650524/r/il/b75356/4870695905/il_570xN.4870695905_kuvb.jpg" },
    { id: 4, name: "Gift 3", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://images-cdn.ubuy.co.in/63f7d71f4e86400af61ec767-kinrex-happy-mother-39-s-day-stuffed.jpg" },
    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/71ousuK29cL.jpg" },
    { id: 4, name: "Gift 5", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBVdw8tjRdylPYvyubmFmLDp6b-8i_GFQkYQ&s" },
    { id: 4, name: "Gift 6", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSJ8wfccxDKWAEtGKI2Txzk-bua3wfgA1aN9w&s" },
    { id: 4, name: "Gift 7", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYSdH1EsNui4f2mi3WmJPqH1SVd0UuIUB6Vw&s" },
    { id: 4, name: "Gift 8", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxFacx9QN4IOv8SilJQP_x9qTxNVaLVGyTlg&s" },
    { id: 4, name: "Gift 9", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRK-Tt4cOWqPhxMO9jFHmYz2Fu7GEwCo0Hk2g&s" },
    { id: 4, name: "Gift 10", price: 34.99, category: "teddy-bears", occasion: "mothers-day", imageUrl: "https://plushland.com/cdn/shop/products/SKU98-003BHappyMother_sDayBearWhite6_REV_1024x1024.jpg" },


    { id: 4, name: "Gift 1", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://i.etsystatic.com/40087644/r/il/b2dc46/5055922182/il_570xN.5055922182_qx7r.jpg" },
    { id: 4, name: "Gift 2", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/712MVtBBfwL._AC_UF1000,1000_QL80_.jpg" },
    { id: 4, name: "Gift 3", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGp1VowgYV9qZ8CJIB7etDk06vjFBLDNCFqw&s" },
    { id: 4, name: "Gift 4", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://images-cdn.ubuy.co.in/63724fe9a6087556a752ce59-me-to-you-tatty-teddy-bear-fathers-day.jpg" },
    { id: 4, name: "Gift 5", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxiwWnlS0iKMmtbn7HsJgWDqwniAyB4Ah-5w&s" },
    { id: 4, name: "Gift 6", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvrj9E4Tg0ZOlsfi-kvQQdDm-VLdsmTg9kLA&s" },
    { id: 4, name: "Gift 7", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvS4Jap3a7HANahGeONoEOzLJRbOw7dAzvow&s" },
    { id: 4, name: "Gift 8", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoT2O3I6rwORFE5UF49esJvmPWEAUxTYFIAQ&s" },
    { id: 4, name: "Gift 9", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6LLm__JovgEFWX7XhxDe4HKd3pCoCrrXMnQ&s" },
    { id: 4, name: "Gift 10", price: 34.99, category: "teddy-bears", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB-gMEOW_d87fImhlCrvlgV_VhB9UaRgW-Gw&s" },

    
    { id: 5, name: "Gift 1", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61ZgTBDaijL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 2", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://homafy.com/wp-content/uploads/2023/06/Happy-birthday-pillow-gift-for-girl.jpg" },
    { id: 5, name: "Gift 3", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuvzHgVngyCewFLEWPAQmXKliZX0mljwicCQ&s" },
    { id: 5, name: "Gift 4", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkLMOFplSkMrktFB0r9ewusBOBJ9ORO8ZOvA&s" },
    { id: 5, name: "Gift 5", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzOVV0QfQLRhbODHM8PT2XOzDYD1ANpJZMew&s" },
    { id: 5, name: "Gift 6", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfqH1CD2JYQZt8SBs2EurGZLQTi7y_EdThhA&s" },
    { id: 5, name: "Gift 7", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-pB6zq8Hy51T3cjEok6q3DxsL0WjOtGUkxg&s" },
    { id: 5, name: "Gift 8", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjqPgS7lqif9Vr8EQdW1shvPcaDEb13rNPjQ&s" },
    { id: 5, name: "Gift 9", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://images.meesho.com/images/products/84833581/s8rp5_512.webp" },
    { id: 5, name: "Gift 10", price: 29.99, category: "pillow-cases", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGE1GbmGh5XbVH-2MPOvto9MBHokvDdebcbg&s" },

    { id: 5, name: "Gift 1", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/61FjG0xmPvL.jpg" },
    { id: 5, name: "Gift 2", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/61Dfw-e4uPL.jpg" },
    { id: 5, name: "Gift 3", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://homafy.com/wp-content/uploads/2023/06/Anniversary-pillow.jpg" },
    { id: 5, name: "Gift 4", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://cdn.togetherv.com/happy-anniversary-white-aubergine-personalised-printed-cushion-sub1_1655706140.webp" },
    { id: 5, name: "Gift 5", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://assets.winni.in/product/primary/2022/6/61355.jpeg?dpr=1&w=600" },
    { id: 5, name: "Gift 6", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/61N9DLquXQL._AC_UF1000,1000_QL80_.jpg" },
    { id: 5, name: "Gift 7", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://images.meesho.com/images/products/119873923/xoozf_512.webp" },
    { id: 5, name: "Gift 8", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6bro-oWQdr1jbsSe36dtr_hk-m4k5jRhJZA&s" },
    { id: 5, name: "Gift 9", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://i.etsystatic.com/7943186/r/il/341323/4815886091/il_570xN.4815886091_95wr.jpg" },
    { id: 5, name: "Gift 10", price: 29.99, category: "pillow-cases", occasion: "anniversary", imageUrl: "https://assets.winni.in/c_limit,dpr_1,fl_progressive,q_80,w_1000/73103_1st-couple-anniversary-cushion.jpeg" },

    { id: 5, name: "Gift 1", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/51zD09WPbIL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 2", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/51BOwzzpvML._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 3", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://i.etsystatic.com/18814126/r/il/64ab50/4470227771/il_570xN.4470227771_fyv1.jpg" },
    { id: 5, name: "Gift 4", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/81gLGbu1eUL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 5", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/81RCx52blTL.jpg" },
    { id: 5, name: "Gift 6", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/61gnlO0WueL.jpg" },
    { id: 5, name: "Gift 7", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://i.etsystatic.com/29554278/r/il/bbe6c0/3457183424/il_570xN.3457183424_ks96.jpg" },
    { id: 5, name: "Gift 8", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS364dMo-Xuw6oLXAmpms_zrzMHKoFAg_Qy-Q&s" },
    { id: 5, name: "Gift 9", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDlUkacqpcbNL8KvfLqqsX15AP9aPy_pP8JQ&s" },
    { id: 5, name: "Gift 10", price: 29.99, category: "pillow-cases", occasion: "valentines", imageUrl: "https://www.fnp.com/images/pr/m/v300/personalised-cushion-gift.jpg" },

    { id: 5, name: "Gift 1", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/13535516/r/il/9cb219/3618621990/il_570xN.3618621990_ou5x.jpg" },
    { id: 5, name: "Gift 2", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/81V8Pc7gMXL._AC_UF350,350_QL80_.jpg" },
    { id: 5, name: "Gift 3", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/91B5bkJfCIL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 4", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/254964567/kaqwc_512.webp" },
    { id: 5, name: "Gift 5", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/7362571/r/il/6d8a40/1470647146/il_570xN.1470647146_dzmm.jpg" },
    { id: 5, name: "Gift 6", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/51Y40MSKdvL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 7", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/253130664/kayvc_512.webp" },
    { id: 5, name: "Gift 8", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQIfkRs43v_Z1Gjy7ftroGbF4fCTizOvTDo6Q&s" },
    { id: 5, name: "Gift 9", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/71p+FxY-LZL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 10", price: 29.99, category: "pillow-cases", occasion: "mothers-day", imageUrl: "https://images.meesho.com/images/products/254964569/z8yb7_512.webp" },

    { id: 5, name: "Gift 1", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/51UjM4FihfL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 2", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/614mJ15J-8L._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 3", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://i.etsystatic.com/20724777/r/il/b30b3f/3906788406/il_570xN.3906788406_7914.jpg" },
    { id: 5, name: "Gift 4", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/71JZS+J9YzS._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 5", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUWGHc8uHvQXm1jscNNyV9jD9WiHZ7E-UXoQ&s" },
    { id: 5, name: "Gift 6", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/51j5XBUmgqL._AC_UF894,1000_QL80_.jpg" },
    { id: 5, name: "Gift 7", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://images.meesho.com/images/products/269962679/xq9wh_512.webp" },
    { id: 5, name: "Gift 8", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/61W7A9hZqgS.jpg" },
    { id: 5, name: "Gift 9", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://i.etsystatic.com/19119334/r/il/1ed9dd/2309171729/il_570xN.2309171729_tmzd.jpg" },
    { id: 5, name: "Gift 10", price: 29.99, category: "pillow-cases", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/71660hqZWlL.jpg" },


   
    { id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61eOFpWFOQL.jpg" },

    {id: 6, name: "Gift 1", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61jINGaMB0L._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 2", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61bQNRLdwbL.jpg" },
    {id: 6, name: "Gift 3", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMd21G-11rtvHopMZ9IJYx708jSJ4kvHgEUg&s" },
    {id: 6, name: "Gift 4", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRJre6nVsrvP_d2z1EEwfdaFYSglQRWnwlgA&s" },
    {id: 6, name: "Gift 5", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/71hls5fjDIL.jpg" },
    {id: 6, name: "Gift 6", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTh0sRn9feugt1wJzUGVsoyhIGQvvoiOjx_fg&s" },
    {id: 6, name: "Gift 7", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNWwNHhyyUbndERKnJoLERPAoeOKbDLu_t-g&s" },
    {id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqeV0dS_IuhCHlNygeuiQ0Ab8_04SxTZKAdQ&s" },
    {id: 6, name: "Gift 9", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://images.prestogifts.com/upload/Missing-Listings/Lamps/3D-MOON-40-17-CM-BIRTHDAY/1431/635235b849a88_1118_2420_image-1200x1200_2_210909162956_2_11zon.jpg" },
    {id: 6, name: "Gift 10", price: 34.99, category: "3d-lamps", occasion: "birthday", imageUrl: "https://images.prestogifts.com/upload/Missing-Listings/Lamps/3D-MOON-40-17-CM-BIRTHDAY/1431/635235b80680b_1118_2420_image-1200x1200_1_210909162956_1_11zon.jpg" },

    {id: 6, name: "Gift 1", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/81OUQ5QrbnL.jpg" },
    {id: 6, name: "Gift 2", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://www.fnp.com//images/pr/l/v20250327151901/personalised-glow-acrylic-lamp_2.jpg" },
    {id: 6, name: "Gift 3", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://images.prestogifts.com/upload/Picture-Optimization/3D-Customised-Lamps/3D-HEART-LAMP-AVSM/1431x1431/67f6203833958_3D-HEART-LAMP-AVSM-Img-1.webp" },
    {id: 6, name: "Gift 4", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://images.prestogifts.com/upload/Picture-Optimization/3D-Customised-Lamps/3D-HEART-LAMP-AVSM/1431x1431/67f6203833958_3D-HEART-LAMP-AVSM-Img-1.webp" },
    {id: 6, name: "Gift 5", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/table-lamp/h/k/c/3d-illusion-lamp-anniversary-gift-with-names-and-photo-lv-012-original-imah3zy2wzpy3hcx.jpeg?q=90&crop=false" },
    {id: 6, name: "Gift 6", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0MunGcxKM2RbgDzNYW9Km_HPWmbsWW2gUJQ&s" },
    {id: 6, name: "Gift 7", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZZC62BE14Z8j2HQdZQm7LP_TwZJ18Yxgy6w&s" },
    {id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://images.meesho.com/images/products/364513551/kains_512.webp" },
    {id: 6, name: "Gift 9", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://i.etsystatic.com/27865965/r/il/90774a/4161485988/il_570xN.4161485988_3yiu.jpg" },
    {id: 6, name: "Gift 10", price: 34.99, category: "3d-lamps", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/71ChlxNybhL.jpg" },

    {id: 6, name: "Gift 1", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkTymjx5iHALvjVLvtrd4eu66IUT-6BGvzyg&s" },
    {id: 6, name: "Gift 2", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/81OUQ5QrbnL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 3", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://m.media-amazon.com/images/I/81iwhtolH5L._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 4", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2m8SnFxIiaDC8XUnxEjOI1BRgg7QqekEOXg&s" },
    {id: 6, name: "Gift 5", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://i.etsystatic.com/27865965/r/il/90774a/4161485988/il_570xN.4161485988_3yiu.jpg" },
    {id: 6, name: "Gift 6", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThjfZT3R9B4_TttAkdO3k9ZcI7wmtY2Tz5qw&s" },
    {id: 6, name: "Gift 7", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://rukminim2.flixcart.com/image/850/1000/xif0q/table-lamp/k/g/e/acrylic-personalized-3d-led-lamp-with-uv-printed-photo-for-original-imaghnfyuwfcmfws.jpeg?q=90&crop=false" },
    {id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://s.alicdn.com/@sc04/kf/H69a32fd06a984a8d86c30f06cd1d8588B.jpg_720x720q50.jpg" },
    {id: 6, name: "Gift 9", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlZzoJK4ieBIJ056JNfqiqwE6jDWSBbzUTMQ&s" },
    {id: 6, name: "Gift 10", price: 34.99, category: "3d-lamps", occasion: "valentines", imageUrl: "https://images.meesho.com/images/products/202021147/hqlqi_512.webp" },

    {id: 6, name: "Gift 1", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61eOFpWFOQL.jpg" },
    {id: 6, name: "Gift 2", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61rtJI3RtUL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 3", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61msCNMvDIL.jpg" },
    {id: 6, name: "Gift 4", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61NA6cw6OEL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 5", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61hqjwKSMmL._AC_UF350,350_QL80_.jpg" },
    {id: 6, name: "Gift 6", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTnT5rvMoZ13WCohEMj1QZMw3t23GyOsTRpg&s" },
    {id: 6, name: "Gift 7", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/61tZlBpeInL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/71r1lMElfxL.jpg" },
    {id: 6, name: "Gift 9", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/614Vo2CeyxL.jpg" },
    {id: 6, name: "Gift 10", price: 34.99, category: "3d-lamps", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/71VdYq6X6ML._AC_UF1000,1000_QL80_.jpg" },

    {id: 6, name: "Gift 1", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/61efUtziQbL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 2", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/51AKDaIhV+L._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 3", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT91mm197XPfm38EoJyXXul11wa8cLNuLEi_w&s" },
    {id: 6, name: "Gift 4", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/71m30L4JzxL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 5", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/611ZFvOmpIL._AC_UF1000,1000_QL80_.jpg" },
    {id: 6, name: "Gift 6", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUrN9QOgGoEkXDun7wzzINJmn1r6sZx643nw&s" },
    {id: 6, name: "Gift 7", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://images.prestogifts.com/upload/birthday/Father/3D-MOON-40P-3D-MOON-40-PREMIUM/1431x1431/627364077e913_Frint1-black-base.jpg" },
    {id: 6, name: "Gift 8", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://5.imimg.com/data5/SELLER/Default/2024/7/434059404/KU/GI/EG/30158656/shayona-3d-illusion-light-lamp-gifts-for-daddy-on-fathers-day-birthday-from-son-daughter.jpg" },
    {id: 6, name: "Gift 9", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFr4Dpfw6Rullgj9EAsaY__RGK_Lq4-4FzvQ&s" },
    {id: 6, name: "Gift 10", price: 34.99, category: "3d-lamps", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuWeybgiaCBVPN82i9Lq1gbede1Nn23et27w&s" },


    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjsBW5XCQYMeVtNlGyd90O4agtZkD40ndhRg&s" },

    { id: 7, name: "Gift 1", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://m.media-amazon.com/images/I/61vWL7ZmRqL._AC_UY1100_.jpg" },
    { id: 7, name: "Gift 2", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM4xgV2FGe1vWj_phyOv8lMUJJcCeUYTt_ZQ&s" },
    { id: 7, name: "Gift 3", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkFXtPW91cQY7qHSe_nKQwCETEUolsw3v0CA&s" },
    { id: 7, name: "Gift 4", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://i0.wp.com/shwasam.co.in/wp-content/uploads/2024/02/SCC7277.jpg?fit=1200%2C1600&ssl=1" },
    { id: 7, name: "Gift 5", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwxZZJfIIlSEBD-WirxjNiadmBp3CPXD70EQ&s" },
    { id: 7, name: "Gift 6", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyLI5tt4tCTb6VcNyzdc3OaSd4Bka90EigRw&s" },
    { id: 7, name: "Gift 7", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPKmS-M9MXNdjHd2P0V6MpR14or-kQIm3AVQ&s" },
    { id: 7, name: "Gift 8", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzOL4h_PbLnQMhTD65BIzVshBBl4AQ0n4iVQ&s" },
    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://images-cdn.ubuy.co.in/667defa4d5509c5a67767e20-hadiah-hari-kasih-sayang-untuk-dia.jpg" },
    { id: 7, name: "Gift 10", price: 25.99, category: "jewellery", occasion: "birthday", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp1Ry5UA7X10KUCsTnDqar7mZBB4mylyWVtg&s" },

    { id: 7, name: "Gift 1", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiYHdDhZ7MpvLeZSt5SV4QgA5uhTtsZSaScg&s" },
    { id: 7, name: "Gift 2", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/41j8EM-5yUL._AC_UY1100_.jpg" },
    { id: 7, name: "Gift 3", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/619bvG0SYRL._AC_UY1100_.jpg" },
    { id: 7, name: "Gift 4", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRX6Mzeo0jrNhwLltBK_2PNIaNcI-mTpMfxlA&s" },
    { id: 7, name: "Gift 5", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://m.media-amazon.com/images/I/619qvkzGkcL._AC_UY1100_.jpg" },
    { id: 7, name: "Gift 6", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://www.giva.co/cdn/shop/files/Anniversary_Gift_Colletion_Banner_-_Phone.jpg?v=1744807160&width=700" },
    { id: 7, name: "Gift 7", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2MLRXQ-bZnSbgOFqVSpgxT4R7A-nIf20-XA&s" },
    { id: 7, name: "Gift 8", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUeMDWR6w9NkjBBV4FXMwN2f0HdwyI1hI5hg&s" },
    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_0Sg0UGlUTYo3nZfOPuS4BKUtzMWQ6uy6tg&s" },
    { id: 7, name: "Gift 10", price: 25.99, category: "jewellery", occasion: "anniversary", imageUrl: "https://www.jiomart.com/images/product/original/rvbuoiu2ju/catx-jewellers-rose-gold-finger-ring-for-women-accessories-jewellery-for-women-birthday-gift-for-girls-and-women-anniversary-gift-for-wife-product-images-rvbuoiu2ju-0-202310081632.jpg?im=Resize=(500,630)" },

    { id: 7, name: "Gift 1", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6gKjZjnFp31k9c1M1Ijw9JjVdhXnzwGmp3Q&s" },
    { id: 7, name: "Gift 2", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://www.giva.co/cdn/shop/files/Valentine_Sets_phone.jpg?v=1676497183&width=700" },
    { id: 7, name: "Gift 3", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRScLlCOeplJB66ZF2Mk7jNOgnXll1I4Kj5lg&s" },
    { id: 7, name: "Gift 4", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqFuZEpvGep-Qn1-xKDm14PDibhTkUxxGHjg&s" },
    { id: 7, name: "Gift 5", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRq20-JMBSKRZTn6TDXiBZcaDC4Zte43-_kEA&s" },
    { id: 7, name: "Gift 6", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7qpxjxkVN6L5Gm_HrLAK4twhy4kO9e30ftw&s" },
    { id: 7, name: "Gift 7", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://sterlyn.in/cdn/shop/files/transformation-14242-a464a73e-49d9-4463-8b8b-e7448db459e9.jpg?v=1723464996&width=1445https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQx_TGhx2MGQqRs6XKBvneEXCihEv3tJm_fJw&s" },
    { id: 7, name: "Gift 8", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://i.pinimg.com/564x/fa/37/77/fa377704dbae4ffa6d903fb1425f6f2b.jpg" },
    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1nBcQqanE7OypAEGOc73zIp7Vk5DrfDlGWg&s" },
    { id: 7, name: "Gift 10", price: 25.99, category: "jewellery", occasion: "valentines", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTE3_7wSwFz0TIwg0O5rj7qpQMR0WBsB3bYVg&s" },

    { id: 7, name: "Gift 1", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/5152054/r/il/f502ad/1357846721/il_570xN.1357846721_lb0k.jpg" },
    { id: 7, name: "Gift 2", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMe5sTUhKD17bimORfjwBdAy_fu3wkyFGkqA&s" },
    { id: 7, name: "Gift 3", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://m.media-amazon.com/images/I/710lW1nd5xL._AC_UY1100_.jpg" },
    { id: 7, name: "Gift 4", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://i.etsystatic.com/31719753/r/il/f8b047/3408939784/il_570xN.3408939784_4g6i.jpg" },
    { id: 7, name: "Gift 5", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://preciousjewels.be/blog/wp-content/uploads/2023/04/Artboard-8-copy-2-1.png" },
    { id: 7, name: "Gift 6", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcWYlGSB1tPtPQLXEolamx1vpfAqgdLQ_Lww&s" },
    { id: 7, name: "Gift 7", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkBeK0T_kvR-PCpAySgQh61yvZ1xltxGJTPw&s" },
    { id: 7, name: "Gift 8", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://cdn.igp.com/f_auto,q_auto,t_pnopt9prodlp/products/p-shimmering-moments-mother-s-day-gift-combo-407542-m.jpg" },
    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT96FU8opB209KO6DPu_QYHRY9-Jt5kHj8B-Q&s" },
    { id: 7, name: "Gift 10", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-zwLJpa_P9H-hpXcLO0rxIJF0iwx81oOi3g&s" },
    { id: 7, name: "Gift 11", price: 25.99, category: "jewellery", occasion: "mothers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsMGPFdXsO_eQgSzakL823XpOFRhijVMoLHQ&s" },

    { id: 7, name: "Gift 1", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYIJllFHkJqUeCp0oBtcBhHAO3OgqEFRni6A&s" },
    { id: 7, name: "Gift 2", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQavpQVetSIx2KFKunVwPew1YzOirSL78k7xw&s" },
    { id: 7, name: "Gift 3", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSooeF6599DyeNyl-Lml24zlbkvr2nCCERTLA&s" },
    { id: 7, name: "Gift 4", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKHxRxeEEO1c_aLHkE2Jyv-STojhcMcZE5w&s" },
    { id: 7, name: "Gift 5", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://cdn.shopify.com/s/files/1/0467/9116/4053/files/Men_s_Father_s_Day_jewellery_gifts_including_cuff_bracelets_and_rings_1024x1024.png?v=1712916935" },
    { id: 7, name: "Gift 6", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhYd7hTs62wka5gietKQP_QEZQPl2XTb4efWzvGdDLmMOxgM7rJQfknQyXaWws5CuoL-w&usqp=CAU" },
    { id: 7, name: "Gift 7", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0qfBdCkhKR38uQEMYXU--FgPuO0cjvgz_WMgcI8pKIdf4zyWfo-ff3KO5DAvOzJZ0HYA&usqp=CAU" },
    { id: 7, name: "Gift 8", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBKYvpOB-HPh77FaDg_kGvJRQo2JoCoDhF9w&s" },
    { id: 7, name: "Gift 9", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://m.media-amazon.com/images/I/51QzM5ATZoL._AC_UY1100_.jpg" },
 
    { id: 7, name: "Gift 10", price: 25.99, category: "jewellery", occasion: "fathers-day", imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_TOlgFTKskrQB6g9VQqg-8dp0ii08tGi75A&s" }



];

 const occasionMessages = {
    birthday: [
        (name) => `🎉 Happy Birthday, ${name}! May your day be filled with joy and laughter! 🎂🥳`,
        (name) => `🎈 Wishing you an amazing birthday, ${name}! Enjoy every moment! 🎁💖`,
        (name) => `🎂 Dear ${name}, may your birthday be as wonderful as you are! 🌟🎊`,
        (name) => `🥳 Happy Birthday ${name}! Sending you lots of love and hugs! 🤗💝`,
        (name) => `🎁 To ${name}, wishing you a day full of love and happiness! 🎉✨`,
        (name) => `🎉 Cheers to you on your birthday, ${name}! Have a blast! 🍰🎈`,
        (name) => `💖 Happy Birthday ${name}! May your dreams come true today! 🌈🎂`,
        (name) => `🌟 ${name}, celebrate big today! You deserve the best birthday ever! 🎉🎁`,
        (name) => `🎂 Sending warm wishes your way, ${name}. Happy Birthday! 🎈❤️`,
        (name) => `🎉 Hey ${name}, it's your day! Shine bright and smile wide! 🥳💫`,
        (name) => `🎁 ${name}, may this birthday be the start of your best year yet! 🌟🎂`,
        (name) => `🥳 Happy Birthday ${name}! Celebrate with joy and love! 🎉💖`,
        (name) => `🎈 Wishing you endless happiness today, ${name}! Have fun! 🎂🎊`,
        (name) => `💝 To ${name}, a very happy birthday filled with love! 🎁🎉`,
        (name) => `🎉 ${name}, make every moment count today! Happy Birthday! 🎂🌟`
    ],
    anniversary: [
        (name) => `💞 Happy Anniversary, ${name}! Wishing you endless love and happiness! 🌹✨`,
        (name) => `🎉 Cheers to your special day, ${name}! May your love grow stronger! 💖🥂`,
        (name) => `🌹 Dear ${name}, celebrating your beautiful journey together! Happy Anniversary! 💑🎊`,
        (name) => `💖 ${name}, may your anniversary be filled with cherished memories and love! 💝🎉`,
        (name) => `🥂 Happy Anniversary, ${name}! Here's to many more wonderful years! 🎉❤️`,
        (name) => `💐 Wishing you joy and love on your anniversary, ${name}! 🌸✨`,
        (name) => `🎊 ${name}, may your love story continue to inspire! Happy Anniversary! 💞🥳`,
        (name) => `💖 Happy Anniversary to you, ${name}! Celebrate your love today! 🌹🎉`,
        (name) => `🌟 ${name}, sending warm wishes on your anniversary! Cheers to love! 🥂💝`,
        (name) => `💞 To ${name}, happy anniversary! Love always wins! 💖🎊`,
        (name) => `🥳 Celebrating your love today, ${name}! Happy Anniversary! 🎉💐`,
        (name) => `💝 ${name}, wishing you a lifetime of love and happiness! Happy Anniversary! 🌹✨`,
        (name) => `🎉 Cheers to you, ${name}, on your special day! Happy Anniversary! 🥂💖`,
        (name) => `💐 May your anniversary be filled with laughter and joy, ${name}! 🎊🌟`,
        (name) => `💖 ${name}, your love is inspiring! Happy Anniversary! 💞🎉`
    ],
  fathersday: [
        (name) => `Happy Father's Day, ${name}! You're my role model and hero.`,
        (name) => `Dear ${name}, your strength and love inspire me every day.`,
        (name) => `To the best dad ever — Happy Father’s Day, ${name}!`,
        (name) => `Thank you for your guidance and support, ${name}.`,
        (name) => `Happy Father's Day, ${name}! You mean the world to me.`,
        (name) => `${name}, your love is the foundation of our family.`,
        (name) => `Wishing you joy and love this Father's Day, ${name}.`,
        (name) => `${name}, you’ve always been my biggest supporter.`,
        (name) => `Cheers to the greatest dad, ${name}!`,
        (name) => `With love and hugs, Happy Father’s Day, ${name}.`,
        (name) => `You’re a true hero, ${name}. Enjoy your special day!`,
        (name) => `Thanks for being the best, ${name}!`,
        (name) => `Happy Father’s Day to the kindest soul, ${name}.`,
        (name) => `Forever grateful for you, ${name}.`,
        (name) => `You make life better, ${name}. Happy Father’s Day!`
    ],

    mothersday: [
        (name) => `Happy Mother’s Day, ${name}! You're my heart and soul.`,
        (name) => `To the most loving mom, ${name}, thank you for everything.`,
        (name) => `Dear ${name}, your love makes the world brighter.`,
        (name) => `You're a blessing, ${name}. Happy Mother's Day!`,
        (name) => `Sending all my love to you today, ${name}.`,
        (name) => `You're the best mom, ${name}. I'm lucky to have you.`,
        (name) => `Thanks for your endless love, ${name}.`,
        (name) => `Happy Mother’s Day, ${name}! You’re everything to me.`,
        (name) => `You light up our lives, ${name}.`,
        (name) => `Wishing a beautiful day to a beautiful soul, ${name}.`,
        (name) => `Thank you for every hug and smile, ${name}.`,
        (name) => `${name}, you’re my forever best friend.`,
        (name) => `Cheers to you, ${name}, on Mother’s Day!`,
        (name) => `You’re simply amazing, ${name}.`,
        (name) => `Love you always, ${name}! Happy Mother’s Day!`
    ],

    valentinesday: [
        (name) => `Happy Valentine's Day, ${name}! You are my sunshine.`,
        (name) => `To my love, ${name} — every moment with you is special.`,
        (name) => `Wishing you a heart full of love today, ${name}.`,
        (name) => `${name}, you complete my world.`,
        (name) => `You are my heart’s favorite, ${name}.`,
        (name) => `With all my love to you, ${name}, this Valentine’s Day.`,
        (name) => `I adore you, ${name}. Be my Valentine forever.`,
        (name) => `You're the sweetest person I know, ${name}.`,
        (name) => `Roses are red, violets are blue, ${name}, I’m lucky to have you.`,
        (name) => `Love you more each day, ${name}.`,
        (name) => `You’re the best thing that ever happened to me, ${name}.`,
        (name) => `Let’s make memories together, ${name}.`,
        (name) => `Forever yours, ${name}.`,
        (name) => `You're my today and all my tomorrows, ${name}.`,
        (name) => `To my one and only — Happy Valentine’s Day, ${name}!`
    
    ]
};


function renderProducts(productsToDisplay) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    productsToDisplay.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-item');
        productDiv.setAttribute('data-category', product.category);
        productDiv.setAttribute('data-occasion', product.occasion);
        productDiv.innerHTML = `
            <img src="${product.imageUrl}" alt="${product.name}">
            <div class="product-details">
                <h3>${product.name}</h3>
                <p>Price: Rs ${product.price.toFixed(2)}</p>
                <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
                <button class="buy-now" data-id="${product.id}" data-occasion="${product.occasion}">Buy Now</button>
            </div>
        `;
        productList.appendChild(productDiv);
    });
}

function filterProducts(event) {
    event.preventDefault();
    const category = document.getElementById('category').value;
    const occasion = document.getElementById('occasion').value;

    const filteredProducts = products.filter(product => {
        const categoryMatch = category === 'all' || product.category === category;
        const occasionMatch = occasion === 'all' || product.occasion === occasion;
        return categoryMatch && occasionMatch;
    });

    renderProducts(filteredProducts);
}

document.getElementById('filter-form').addEventListener('submit', filterProducts);

// Modal & Buy Now logic
let selectedProductId = null;
let selectedOccasion = '';
let selectedProduct = null; // ✅ Correct product will be stored here
let currentMessage = '';
let messageIndex = 0;

document.addEventListener('click', function(event) {
    if (event.target.classList.contains('add-to-cart')) {
        const productId = event.target.getAttribute('data-id');
        const product = products.find(p => p.id == productId);
        const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

        const existing = cartItems.find(item => item.id === product.id);
        if (existing) {
            existing.quantity += 1;
        } else {
            cartItems.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.imageUrl,
                quantity: 1
            });
        }

        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        alert(`${product.name} added to cart!`);

    } else if (event.target.classList.contains('buy-now')) {
        selectedProductId = event.target.getAttribute('data-id');
        selectedOccasion = event.target.getAttribute('data-occasion');
        selectedProduct = products.find(p => p.id == selectedProductId); // ✅ Set here

        document.getElementById('buyNowModal').classList.add('active');
        document.body.classList.add('modal-open');

        document.getElementById('recipientName').value = '';
        document.getElementById('location').value = '';
        document.getElementById('userMessage').value = '';
        messageIndex = 0;
        generateGiftMessage();
    } else if (event.target.id === 'cancelBuyNow') {
        document.getElementById('buyNowModal').classList.remove('active');
        document.body.classList.remove('modal-open');
        removeCardInputs();
    }
});

document.getElementById('recipientName').addEventListener('input', generateGiftMessage);

const paymentSelect = document.getElementById('payment-method');
const upiInputContainer = document.getElementById('upi-input-container');
const buyNowModalContent = document.querySelector('#buyNowModal .modal-content');
let cardInputsContainer = null;

function createCardInputs() {
    if (cardInputsContainer) return;
    cardInputsContainer = document.createElement('div');
    cardInputsContainer.id = 'card-inputs';
    cardInputsContainer.innerHTML = `
        <label for="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" maxlength="16" placeholder="1234 5678 9012 3456" required />
        <label for="expiryDate">Expiry Date (MM/YY):</label>
        <input type="text" id="expiryDate" maxlength="5" placeholder="MM/YY" required />
        <label for="cvv">CVV:</label>
        <input type="password" id="cvv" maxlength="3" placeholder="123" required />
    `;
    buyNowModalContent.insertBefore(cardInputsContainer, buyNowModalContent.querySelector('.modal-buttons'));
}

function removeCardInputs() {
    if (cardInputsContainer) {
        cardInputsContainer.remove();
        cardInputsContainer = null;
    }
}

paymentSelect.addEventListener('change', () => {
    const value = paymentSelect.value;
    if (value === 'upi') {
        upiInputContainer.style.display = 'block';
        removeCardInputs();
    } else if (value === 'card') {
        upiInputContainer.style.display = 'none';
        createCardInputs();
    } else {
        upiInputContainer.style.display = 'none';
        removeCardInputs();
    }
});

document.getElementById('confirmBuyNow').addEventListener('click', () => {
    const files = document.getElementById('photoUpload').files;
    const location = document.getElementById('location').value.trim();
    const recipientName = document.getElementById('recipientName').value.trim();
    const paymentMethod = paymentSelect.value;
    const userMsg = document.getElementById('userMessage').value.trim();
    const upiId = document.getElementById('upiId')?.value.trim();

    if (files.length === 0 || files.length > 6) {
        alert("Please upload between 1 and 6 photos.");
        return;
    }
    if (!recipientName) {
        alert("Please enter the recipient's name.");
        return;
    }
    if (!location) {
        alert("Please enter your location.");
        return;
    }
    if (!paymentMethod) {
        alert("Please select a payment method.");
        return;
    }

    currentMessage = userMsg || currentMessage;
    const product = selectedProduct; // ✅ This ensures correct image

    const orders = JSON.parse(localStorage.getItem("giftoraOrders")) || [];
    const orderData = {
        imageUrl: product.imageUrl,
        name: product.name,
        price: product.price,
        occasion: selectedOccasion,
        recipient: recipientName,
        date: new Date().toLocaleDateString()
    };

    if (paymentMethod === 'card') {
        const cardNumber = document.getElementById('cardNumber').value.replace(/\s+/g, '');
        const expiryDate = document.getElementById('expiryDate').value.trim();
        const cvv = document.getElementById('cvv').value.trim();

        const cardNumberValid = /^\d{16}$/.test(cardNumber);
        const expiryValid = /^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate);
        const cvvValid = /^\d{3}$/.test(cvv);

        if (!cardNumberValid || !expiryValid || !cvvValid) {
            alert("Please enter valid card details.");
            return;
        }

        alert("Verifying card details...");
        setTimeout(() => {
            alert("Card verified. Payment successful! Order confirmed.");
            orders.push(orderData);
            localStorage.setItem("giftoraOrders", JSON.stringify(orders));
            document.getElementById('buyNowModal').classList.remove('active');
            document.body.classList.remove('modal-open');
            removeCardInputs();
        }, 1000);

    } else if (paymentMethod === 'upi') {
        const isValidUpi = /^[\w.-]+@[\w]+$/.test(upiId);
        if (!upiId || !isValidUpi) {
            alert("Please enter a valid UPI ID (e.g., name@upi).");
            return;
        }
        alert(`Processing payment via UPI ID: ${upiId}...`);
        setTimeout(() => {
            alert("✅ Payment successful via UPI! Your order has been placed.");
            orders.push(orderData);
            localStorage.setItem("giftoraOrders", JSON.stringify(orders));
            document.getElementById('buyNowModal').classList.remove('active');
            document.body.classList.remove('modal-open');
            removeCardInputs();
        }, 1000);

    } else if (paymentMethod === 'cash') {
        alert("Order confirmed! Please pay with cash upon delivery.");
        orders.push(orderData);
        localStorage.setItem("giftoraOrders", JSON.stringify(orders));
        document.getElementById('buyNowModal').classList.remove('active');
        document.body.classList.remove('modal-open');
        removeCardInputs();
    } else {
        alert("Unknown payment method selected.");
    }
});

// === Auto-Generate Personalized Gift Messages ===
const messageOutput = document.getElementById('generatedMessage');
const regenerateBtn = document.getElementById('regenerateMessage');
const userMessageInput = document.getElementById('userMessage');

regenerateBtn.addEventListener('click', () => {
    if (!userMessageInput.value.trim()) {
        cycleMessage();
    }
});

userMessageInput.addEventListener('input', () => {
    if (userMessageInput.value.trim()) {
        messageOutput.innerText = userMessageInput.value;
    } else {
        messageOutput.innerText = currentMessage;
    }
});

function generateGiftMessage() {
    const name = document.getElementById('recipientName').value.trim() || "Dear";
    if (!selectedOccasion || !occasionMessages[selectedOccasion]) {
        messageOutput.innerText = `🎁 Wishing you a wonderful day, ${name}! 😊`;
        currentMessage = messageOutput.innerText;
        return;
    }
    const msgs = occasionMessages[selectedOccasion];
    currentMessage = msgs[messageIndex](name);
    messageOutput.innerText = currentMessage;
}

function cycleMessage() {
    const name = document.getElementById('recipientName').value.trim() || "Dear";
    if (!selectedOccasion || !occasionMessages[selectedOccasion]) return;
    const msgs = occasionMessages[selectedOccasion];
    messageIndex = (messageIndex + 1) % msgs.length;
    currentMessage = msgs[messageIndex](name);
    messageOutput.innerText = currentMessage;
}

// Initial render
renderProducts(products);
